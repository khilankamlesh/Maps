import java.io.*;
import java.util.*;

//class that behaves like a map
public class LocationMap implements Map<Integer, Location> {

    private static final String LOCATIONS_FILE_NAME = "locations.txt";
    private static final String DIRECTIONS_FILE_NAME = "directions.txt";

    /**
     * create a static locations HashMap
     */
    static HashMap<Integer, Location> locations = new HashMap<>();

    static {
        /*
         * create a FileLogger object
         */
        FileLogger fileLogger = new FileLogger();

        /*
         * create a ConsoleLogger object
         */
        ConsoleLogger consoleLogger = new ConsoleLogger();

        /*
         * Read from LOCATIONS_FILE_NAME so that a user can navigate from one location to another
         * use try-with-resources/catch block for the FileReader
         * extract the location and the description on each line
         * print all locations and descriptions to both console and file
         * check the ExpectedOutput files
         * put the location and a new Location object in the locations HashMap, using temporary empty hashmaps for exits
         */
        try (BufferedReader myReader = new BufferedReader(new FileReader(LOCATIONS_FILE_NAME))) {
            fileLogger.log("Available locations:\n");
            consoleLogger.log("Available locations:\n");
            String line;
            while ((line = myReader.readLine()) != null) {
                String[] splitLine = line.split(",", 2);
                String message = splitLine[0] + ": " + splitLine[1] + "\n";

                fileLogger.log(message);
                consoleLogger.log(message);

                locations.put(Integer.parseInt(splitLine[0]),
                        new Location(Integer.parseInt(splitLine[0]), splitLine[1], new LinkedHashMap<>()));
            }
        } catch (Exception e) {
            System.err.println("Something went wrong in reading locations.txt");
        }

        /*
         * Read from DIRECTIONS_FILE_NAME so that a user can move from A to B, i.e. current location to next location
         * use try-with-resources/catch block for the FileReader
         * extract the 3 elements  on each line: location, direction, destination
         * print all locations, directions and destinations to both console and file
         * check the ExpectedOutput files
         * add the exits for each location
         */
        try (BufferedReader myReader = new BufferedReader(new FileReader(DIRECTIONS_FILE_NAME))) {
            fileLogger.log("Available directions:\n");
            consoleLogger.log("Available directions:\n");

            int location = 0;
            Location temp = new Location(location, null, new LinkedHashMap<>());
            String line;
            while ((line = myReader.readLine()) != null) {
                int prevLocation = location;
                String[] splitLine = line.split(",", 3);
                location = Integer.parseInt(splitLine[0]);
                String direction = splitLine[1];
                int destination = Integer.parseInt(splitLine[2]);

                String message = splitLine[0] + ": " + direction + ": " + splitLine[2] + "\n";

                fileLogger.log(message);
                consoleLogger.log(message);

                if (location != prevLocation){
                    temp = new Location(location, null, new LinkedHashMap<>());
                }
                locations.get(location).addExit(direction,destination);
            }
        } catch (Exception e) {
            System.err.println("Something went wrong in reading directions.txt");
        }

    }

    /*
     *
     * implement all methods for Map
     *
     *
     */
    @Override
    public int size() {
        //
        return locations.size();
    }

    @Override
    public boolean isEmpty() {
        //
        return locations.isEmpty();
    }

    @Override
    public boolean containsKey(Object key) {
        //
        return locations.containsKey(key);
    }

    @Override
    public boolean containsValue(Object value) {
        //
        return locations.containsValue(value);
    }

    @Override
    public Location get(Object key) {
        //
        return locations.get(key);
    }

    @Override
    public Location put(Integer key, Location value) {
        //
        return locations.put(key, value);
    }

    @Override
    public Location remove(Object key) {
        //
        return locations.remove(key);
    }

    @Override
    public void putAll(Map<? extends Integer, ? extends Location> m) {
        //
        locations.putAll(m);
    }

    @Override
    public void clear() {
        //
        locations.clear();
    }

    @Override
    public Set<Integer> keySet() {
        //
        return locations.keySet();
    }

    @Override
    public Collection<Location> values() {
        //
        return locations.values();
    }

    @Override
    public Set<Entry<Integer, Location>> entrySet() {
        //
        return locations.entrySet();
    }
}
