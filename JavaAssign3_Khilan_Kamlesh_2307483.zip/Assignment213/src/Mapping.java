import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Scanner;

public class Mapping {

    public static final int INITIAL_LOCATION = 95;

    /*
     * create a static LocationMap object
     */
    static LocationMap locationMap = new LocationMap();

    /*
     * create a vocabulary HashMap to store all directions a user can go
     */
    HashMap<String, String> vocabulary = new HashMap<>();

    /*
     * create a FileLogger object
     */
    FileLogger fileLogger = new FileLogger();

    /*
     * create a ConsoleLogger object
     */
    ConsoleLogger consoleLogger = new ConsoleLogger();


    public Mapping() {
        /*
         * complete the vocabulary HashMap <Key, Value> with all directions.
         * use the directions.txt file and crosscheck with the ExpectedInput and ExpectedOutput files to find the keys and the values
         */
        vocabulary.put("NORTH", "N");
        vocabulary.put("NORTHEAST", "NE");
        vocabulary.put("EAST", "E");
        vocabulary.put("SOUTHEAST", "SE");
        vocabulary.put("SOUTH", "S");
        vocabulary.put("SOUTHWEST", "SW");
        vocabulary.put("WEST", "W");
        vocabulary.put("NORTHWEST", "NW");
        vocabulary.put("UP", "U");
        vocabulary.put("DOWN", "D");
        vocabulary.put("QUIT", "Q");
    }

    public void mapping() {
        /*
         * create a Scanner object
         */
        Scanner input = new Scanner(System.in);
        /*
         * initialise a location variable with the INITIAL_LOCATION
         */
        int location = INITIAL_LOCATION;

        while (true) {
            /*
             * get the location and print its description to both console and file
             * use the FileLogger and ConsoleLogger objects
             */
            Location thisLocation = locationMap.get(location);
            String description = thisLocation.getDescription();

            fileLogger.log(description + "\n");
            consoleLogger.log(description + "\n");
            /*
             * verify if the location is exit
             */
            if (description.equals("YOU ARE SITTING IN FRONT OF A COMPUTER LEARNING JAVA."))
                break;
            /*
             * get a map of the exits for the location
             */
            LinkedHashMap<String, Integer> exits = new LinkedHashMap<>();
            exits.putAll(thisLocation.getExits());
            /*
             * print the available exits (to both console and file)
             * crosscheck with the ExpectedOutput files
             * Hint: you can use a StringBuilder to append the exits
             */
            StringBuilder sb = new StringBuilder("Available exits are ");
            for (String i : exits.keySet()) {
                sb.append(i).append(", ");
            }
            String message = sb.toString();

            boolean noWord = true;
            while (noWord) {
                fileLogger.log(message + "\n");
                consoleLogger.log(message + "\n");

                //System.out.println(exits);

                /*
                 * input a direction
                 * ensure that the input is converted to uppercase
                 */
                String direction = input.nextLine().toUpperCase();
                String[] words = direction.split(" ");
                /*
                 * are we dealing with a letter / word for the direction to go to?
                 * available inputs are: a letter(the HashMap value), a word (the HashMap key), a string of words that contains the key
                 * crosscheck with the ExpectedInput and ExpectedOutput files for examples of inputs
                 * if the input contains multiple words, extract each word
                 * find the direction to go to using the vocabulary mapping
                 * if multiple viable directions are specified in the input, choose the last one
                 */

                for (String word : words) {
                    if (vocabulary.containsValue(word)) {
                        if (words.length > 1) {
                            fileLogger.log("You cannot go in that direction\n");
                            consoleLogger.log("You cannot go in that direction\n");
                            fileLogger.log(description + "\n");
                            consoleLogger.log(description + "\n");
                        } else {
                            location = exits.get(word);
                            noWord = false;
                        }

                    } else if (vocabulary.containsKey(word)) {
                        word = vocabulary.get(word);
                        location = exits.get(word);
                        noWord = false;
                    }
                }
                if (noWord) {
                    fileLogger.log("You cannot go in that direction\n");
                    consoleLogger.log("You cannot go in that direction\n");
                    fileLogger.log(description + "\n");
                    consoleLogger.log(description + "\n");
                }
            }


            /*
             * if user can go in that direction, then set the location to that direction
             * otherwise print an error message (to both console and file)
             * check the ExpectedOutput files
             */
        }
    }

    public static void main(String[] args) {
        /*
         * run the program from here
         * create a Mapping object
         * start the game
         */
        Mapping start = new Mapping();
        start.mapping();
    }
}
